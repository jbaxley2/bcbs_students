"use strict";

const getId = function (id) { return document.getElementById(id); };

//1. create a constant called displayMessage that will hold a message
// "The change reflected is the least number of coins!" 

const calculateChange = function() {
    let cents, quarters, dimes, nickels, pennies;
    
    // get the number of cents from the user
    cents = Math.floor(parseInt(getId("cents").value));
    
    if (isNaN(cents) || cents < 0 || cents > 99) {
        alert("Please enter a valid number between 0 and 99");
    } else {
        // calculate the number of quarters
        quarters = cents / 25;  // get number of quarters
        quarters = Math.floor(quarters);
        cents = cents % 25;         // assign the remainder to the cents variable

        // calculate the number of dimes
        dimes = cents / 10;     // get number of dimes
        dimes = Math.floor(dimes);
        cents = cents % 10;         // assign the remainder to the cents variable

        // calculate the number of nickels
        nickels = cents / 5;
        nickels = Math.floor(nickels);

        // calculate the number of nickels and pennies
        pennies = cents % 5;

        // display the results of the calculations
        getId("quarters").value = quarters;
        getId("dimes").value = dimes;
        getId("nickels").value = nickels;
        getId("pennies").value = pennies;
        //write out the message here to our new div
    }
};




window.onload = function () {
    getId("calculate").onclick = calculateChange;
    getId("cents").focus();  
};


//2. now change the code (not window.onload) to an object with two methods and one property
// called makechange 
//test using F12