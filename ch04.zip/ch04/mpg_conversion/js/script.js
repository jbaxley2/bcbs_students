//Get the four elements by their IDs into variables; do not use var 

//alert one of the elements to see what it looks like

//create a function that 
//uses those elements' variable names to get their values
//make sure to parseInt
//add the two values together
//write out the value to the Total text box


//attach the listener to the button
