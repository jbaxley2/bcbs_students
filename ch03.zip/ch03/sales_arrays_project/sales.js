//  quarter      1    2      3     4
var region1 = [1540, 1130, 1580, 1105];
//   position   0      1     2     3
var region2 = [2010, 1168, 2305, 4102];
var region3 = [2450, 1847, 2710, 2391];
var region4 = [1845, 1491, 1284, 1575];
var region5 = [2120, 1767, 1599, 3888];

//copy the same div from the last project and make sure to copy the ending element as well

// create a variable called allRegionsSecondQuarter; add all of the arrays'
// 2nd quarters and display allRegionsSecondQuarter to the screen 
//using document.write from before.

//using document.write - write out three break elements

//create a variable called region2Total and use a while loop to 
//create a sum for all four quarters and display to the screen
